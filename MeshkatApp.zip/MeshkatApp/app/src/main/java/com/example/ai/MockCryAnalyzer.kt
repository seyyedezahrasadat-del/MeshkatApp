package com.example.ai

import com.example.model.CryAnalysisResult
import com.example.model.CryCause
import com.example.model.CryProbability
import kotlinx.coroutines.delay
import java.io.File
import kotlin.random.Random

class MockCryAnalyzer {
    suspend fun analyze(audioFile: File, durationSeconds: Int): Result<CryAnalysisResult> {
        delay(2500) // شبیه‌سازی زمان پردازش هوش مصنوعی

        val causes = CryCause.entries
        val topCause = causes[Random.nextInt(causes.size)]
        val topConfidence = Random.nextInt(45, 68)

        var remainingPercent = 100 - topConfidence
        val otherCauses = causes.filter { it != topCause }
        val probabilities = mutableListOf(CryProbability(topCause, topConfidence))

        for (i in otherCauses.indices) {
            val cause = otherCauses[i]
            if (i == otherCauses.lastIndex) {
                probabilities.add(CryProbability(cause, remainingPercent))
            } else {
                val maxAlloc = (remainingPercent - (otherCauses.size - 1 - i)).coerceAtLeast(1)
                val part = Random.nextInt(1, (maxAlloc / 2).coerceAtLeast(2))
                probabilities.add(CryProbability(cause, part))
                remainingPercent -= part
            }
        }

        val painItem = probabilities.find { it.cause == CryCause.PAIN_DISCOMFORT }
        val hasHighPain = (painItem?.percentage ?: 0) >= 20 || topCause == CryCause.PAIN_DISCOMFORT

        return Result.success(
            CryAnalysisResult(
                id = System.currentTimeMillis(),
                durationSeconds = durationSeconds,
                primaryCause = topCause,
                primaryConfidence = topConfidence,
                probabilities = probabilities.sortedByDescending { it.percentage },
                audioFilePath = audioFile.absolutePath,
                hasHighPainOrDistress = hasHighPain
            )
        )
    }
}