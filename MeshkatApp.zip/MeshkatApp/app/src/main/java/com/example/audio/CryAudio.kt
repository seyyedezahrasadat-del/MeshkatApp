package com.example.audio

import android.content.Context
import android.media.MediaPlayer
import android.media.MediaRecorder
import android.os.Build
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.io.File
import java.io.IOException

class CryAudioRecorder(private val context: Context) {
    private var recorder: MediaRecorder? = null
    private var currentFile: File? = null
    private var tickerJob: Job? = null
    private val scope = CoroutineScope(Dispatchers.Default + SupervisorJob())

    private val _isRecording = MutableStateFlow(false)
    val isRecording = _isRecording.asStateFlow()

    private val _recordedDurationSeconds = MutableStateFlow(0)
    val recordedDurationSeconds = _recordedDurationSeconds.asStateFlow()

    private val _audioAmplitude = MutableStateFlow(0f)
    val audioAmplitude = _audioAmplitude.asStateFlow()

    fun startRecording(): File? {
        if (_isRecording.value) return currentFile
        val outputDir = File(context.cacheDir, "meshkat_audio").apply { mkdirs() }
        val file = File(outputDir, "cry_${System.currentTimeMillis()}.m4a")
        currentFile = file

        recorder = (if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) MediaRecorder(context) else @Suppress("DEPRECATION") MediaRecorder()).apply {
            setAudioSource(MediaRecorder.AudioSource.MIC)
            setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
            setAudioEncodingBitRate(128000)
            setAudioSamplingRate(44100)
            setOutputFile(file.absolutePath)
            prepare()
            start()
        }

        _isRecording.value = true
        _recordedDurationSeconds.value = 0

        tickerJob = scope.launch {
            var ticks = 0
            while (isActive && _isRecording.value) {
                delay(100)
                ticks++
                if (ticks % 10 == 0) _recordedDurationSeconds.value += 1
                recorder?.maxAmplitude?.let { amp ->
                    _audioAmplitude.value = (amp / 32767f).coerceIn(0f, 1f)
                }
            }
        }
        return file
    }

    fun stopRecording(): File? {
        tickerJob?.cancel()
        recorder?.run { try { stop(); release() } catch (e: Exception) {} }
        recorder = null
        _isRecording.value = false
        _audioAmplitude.value = 0f
        return currentFile
    }
}

class CryAudioPlayer {
    private var mediaPlayer: MediaPlayer? = null
    private val _isPlaying = MutableStateFlow(false)
    val isPlaying = _isPlaying.asStateFlow()

    private val _progressFraction = MutableStateFlow(0f)
    val progressFraction = _progressFraction.asStateFlow()

    private var progressJob: Job? = null
    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())

    fun play(filePath: String) {
        stop()
        mediaPlayer = MediaPlayer().apply {
            setDataSource(filePath)
            prepare()
            start()
            setOnCompletionListener { _isPlaying.value = false; _progressFraction.value = 0f; progressJob?.cancel() }
        }
        _isPlaying.value = true
        progressJob = scope.launch {
            while (isActive && _isPlaying.value) {
                mediaPlayer?.let { mp ->
                    if (mp.duration > 0) _progressFraction.value = mp.currentPosition.toFloat() / mp.duration.toFloat()
                }
                delay(100)
            }
        }
    }

    fun stop() {
        progressJob?.cancel()
        mediaPlayer?.release()
        mediaPlayer = null
        _isPlaying.value = false
        _progressFraction.value = 0f
    }
}