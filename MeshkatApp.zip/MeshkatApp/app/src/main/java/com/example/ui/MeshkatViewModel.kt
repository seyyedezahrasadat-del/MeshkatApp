package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.ai.MockCryAnalyzer
import com.example.audio.CryAudioPlayer
import com.example.audio.CryAudioRecorder
import com.example.data.CryAppDatabase
import com.example.data.CryMemoryEntity
import com.example.model.CryAnalysisResult
import com.example.model.CryCause
import com.example.model.CryProbability
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.io.File

enum class AppScreen { HOME, RECORD, ANALYZING, RESULT, MEMORIES, ABOUT, SETTINGS }

class MeshkatViewModel(application: Application) : AndroidViewModel(application) {
    val recorder = CryAudioRecorder(application)
    val player = CryAudioPlayer()
    private val analyzer = MockCryAnalyzer()
    private val database = CryAppDatabase.getDatabase(application)

    private val _currentScreen = MutableStateFlow(AppScreen.HOME)
    val currentScreen = _currentScreen.asStateFlow()

    private val _lastRecordedFile = MutableStateFlow<File?>(null)
    val lastRecordedFile = _lastRecordedFile.asStateFlow()

    private val _currentAnalysisResult = MutableStateFlow<CryAnalysisResult?>(null)
    val currentAnalysisResult = _currentAnalysisResult.asStateFlow()

    val memories: StateFlow<List<CryAnalysisResult>> = database.cryMemoryDao().getAllMemories()
        .map { list ->
            list.map { entity ->
                val probs = try {
                    Json.decodeFromString<List<CryProbability>>(entity.probabilitiesJson)
                } catch (e: Exception) { emptyList() }
                CryAnalysisResult(
                    id = entity.id,
                    timestamp = entity.timestamp,
                    durationSeconds = entity.durationSeconds,
                    primaryCause = CryCause.fromName(entity.primaryCause),
                    primaryConfidence = entity.primaryConfidence,
                    probabilities = probs,
                    audioFilePath = entity.audioFilePath,
                    hasHighPainOrDistress = entity.hasHighPainOrDistress
                )
            }
        }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun navigateTo(screen: AppScreen) { _currentScreen.value = screen }

    fun startRecording() {
        player.stop()
        _lastRecordedFile.value = recorder.startRecording()
    }

    fun stopRecording() {
        _lastRecordedFile.value = recorder.stopRecording()
    }

    fun analyzeRecordedCry() {
        val file = _lastRecordedFile.value ?: return
        val duration = recorder.recordedDurationSeconds.value.coerceAtLeast(3)
        _currentScreen.value = AppScreen.ANALYZING

        viewModelScope.launch {
            val result = analyzer.analyze(file, duration)
            result.getOrNull()?.let { res ->
                _currentAnalysisResult.value = res
                database.cryMemoryDao().insertMemory(
                    CryMemoryEntity(
                        timestamp = res.timestamp,
                        durationSeconds = res.durationSeconds,
                        primaryCause = res.primaryCause.name,
                        primaryConfidence = res.primaryConfidence,
                        probabilitiesJson = Json.encodeToString(res.probabilities),
                        audioFilePath = res.audioFilePath,
                        hasHighPainOrDistress = res.hasHighPainOrDistress
                    )
                )
                _currentScreen.value = AppScreen.RESULT
            }
        }
    }

    fun clearAllMemories() {
        viewModelScope.launch { database.cryMemoryDao().clearAll() }
    }
}