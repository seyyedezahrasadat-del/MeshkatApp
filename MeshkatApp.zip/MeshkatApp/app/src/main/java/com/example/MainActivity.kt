package com.example

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.example.model.CryCause
import com.example.ui.AppScreen
import com.example.ui.MeshkatViewModel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

// پالت رنگی پاستلی و کودکانه دخترانه
val MeshkatPinkPrimary = Color(0xFFFF708D)
val MeshkatPinkSecondary = Color(0xFFFF94A9)
val MeshkatPinkBackground = Color(0xFFFFF7F9)
val AlertRed = Color(0xFFE53935)
val TextDark = Color(0xFF374151)
val TextMuted = Color(0xFF9CA3AF)

class MainActivity : ComponentActivity() {
    private val viewModel: MeshkatViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MaterialTheme {
                // فعال‌سازی کامل راست‌به‌چپ (RTL) برای زبان فارسی
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                    MeshkatMainScreen(viewModel)
                }
            }
        }
    }
}

@Composable
fun MeshkatMainScreen(viewModel: MeshkatViewModel) {
    val currentScreen by viewModel.currentScreen.collectAsState()

    BackHandler(enabled = currentScreen != AppScreen.HOME) {
        viewModel.navigateTo(AppScreen.HOME)
    }

    Scaffold(
        containerColor = MeshkatPinkBackground,
        topBar = {
            Surface(
                modifier = Modifier.fillMaxWidth().statusBarsPadding(),
                color = Color.White.copy(alpha = 0.95f),
                shadowElevation = 2.dp
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    if (currentScreen != AppScreen.HOME) {
                        IconButton(onClick = { viewModel.navigateTo(AppScreen.HOME) }) {
                            Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = "بازگشت", tint = MeshkatPinkPrimary)
                        }
                    } else {
                        Text("🧸", fontSize = 24.sp)
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Column {
                        Text(
                            text = if (currentScreen == AppScreen.HOME) "تحلیل گریه مِشکات" else "تحلیل صدای نوزاد 🩷",
                            fontWeight = FontWeight.Bold,
                            color = MeshkatPinkPrimary,
                            fontSize = 17.sp
                        )
                        Text("دستیار آرامش نوزاد و والدین", fontSize = 11.sp, color = TextMuted)
                    }
                }
            }
        },
        bottomBar = {
            NavigationBar(containerColor = Color.White) {
                NavigationBarItem(
                    selected = currentScreen == AppScreen.HOME,
                    onClick = { viewModel.navigateTo(AppScreen.HOME) },
                    icon = { Icon(Icons.Rounded.Home, contentDescription = null) },
                    label = { Text("خانه", fontSize = 11.sp) }
                )
                NavigationBarItem(
                    selected = currentScreen == AppScreen.RECORD,
                    onClick = { viewModel.navigateTo(AppScreen.RECORD) },
                    icon = { Icon(Icons.Rounded.Mic, contentDescription = null) },
                    label = { Text("ضبط صدا", fontSize = 11.sp) }
                )
                NavigationBarItem(
                    selected = currentScreen == AppScreen.MEMORIES,
                    onClick = { viewModel.navigateTo(AppScreen.MEMORIES) },
                    icon = { Icon(Icons.Rounded.Bookmark, contentDescription = null) },
                    label = { Text("خاطرات", fontSize = 11.sp) }
                )
                NavigationBarItem(
                    selected = currentScreen == AppScreen.ABOUT,
                    onClick = { viewModel.navigateTo(AppScreen.ABOUT) },
                    icon = { Icon(Icons.Rounded.Favorite, contentDescription = null) },
                    label = { Text("درباره مشکات", fontSize = 11.sp) }
                )
            }
        }
    ) { padding ->
        Box(modifier = Modifier.fillMaxSize().padding(padding)) {
            when (currentScreen) {
                AppScreen.HOME -> HomeScreen(viewModel)
                AppScreen.RECORD -> RecordScreen(viewModel)
                AppScreen.ANALYZING -> AnalyzingScreen()
                AppScreen.RESULT -> ResultScreen(viewModel)
                AppScreen.MEMORIES -> MemoriesScreen(viewModel)
                AppScreen.ABOUT -> AboutScreen()
                AppScreen.SETTINGS -> Box {}
            }
        }
    }
}

// ------------------- صفحه اصلی (Home) -------------------
@Composable
fun HomeScreen(viewModel: MeshkatViewModel) {
    Column(
        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            elevation = CardDefaults.cardElevation(2.dp)
        ) {
            Column(modifier = Modifier.padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Text("👶🏻", fontSize = 48.sp)
                Spacer(modifier = Modifier.height(8.dp))
                Text("سلام به مِشکات قشنگمون 🩷", fontWeight = FontWeight.Bold, fontSize = 18.sp, color = TextDark)
                Spacer(modifier = Modifier.height(4.dp))
                Text("برای بررسی علت احتمالی بی‌قراری، صدای گریه را ضبط کنید", fontSize = 12.sp, color = TextMuted, textAlign = TextAlign.Center)
            }
        }

        Spacer(modifier = Modifier.height(30.dp))

        // دکمه بزرگ ضبط
        Button(
            onClick = { viewModel.navigateTo(AppScreen.RECORD) },
            modifier = Modifier.fillMaxWidth().height(64.dp),
            shape = RoundedCornerShape(20.dp),
            colors = ButtonDefaults.buttonColors(containerColor = MeshkatPinkPrimary)
        ) {
            Icon(Icons.Rounded.Mic, contentDescription = null, tint = Color.White)
            Spacer(modifier = Modifier.width(8.dp))
            Text("شروع ضبط صدای گریه", fontSize = 16.sp, fontWeight = FontWeight.Bold)
        }

        Spacer(modifier = Modifier.height(24.dp))
        DisclaimerCard()
    }
}

// ------------------- صفحه ضبط صدا (Record) -------------------
@Composable
fun RecordScreen(viewModel: MeshkatViewModel) {
    val context = LocalContext.current
    val isRecording by viewModel.recorder.isRecording.collectAsState()
    val seconds by viewModel.recorder.recordedDurationSeconds.collectAsState()
    val recordedFile by viewModel.lastRecordedFile.collectAsState()

    var hasPermission by remember {
        mutableStateOf(ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED)
    }

    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { isGranted ->
        hasPermission = isGranted
        if (isGranted) viewModel.startRecording()
    }

    Column(
        modifier = Modifier.fillMaxSize().padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text(
            text = if (isRecording) "🔴 در حال ضبط صدای مشکات…" else if (recordedFile != null) "صدای مشکات آماده تحلیل است 🩷" else "دکمه میکروفون را لمس کنید",
            fontSize = 18.sp,
            fontWeight = FontWeight.Bold,
            color = if (isRecording) AlertRed else MeshkatPinkPrimary
        )

        Spacer(modifier = Modifier.height(12.dp))
        Text(String.format(Locale.getDefault(), "%02d:%02d", seconds / 60, seconds % 60), fontSize = 28.sp, fontWeight = FontWeight.Bold, color = TextDark)

        Spacer(modifier = Modifier.height(30.dp))

        // دکمه بزرگ میکروفون
        Button(
            onClick = {
                if (!hasPermission) launcher.launch(Manifest.permission.RECORD_AUDIO)
                else {
                    if (isRecording) viewModel.stopRecording() else viewModel.startRecording()
                }
            },
            modifier = Modifier.size(130.dp),
            shape = CircleShape,
            colors = ButtonDefaults.buttonColors(containerColor = if (isRecording) AlertRed else MeshkatPinkPrimary)
        ) {
            Icon(if (isRecording) Icons.Rounded.Stop else Icons.Rounded.Mic, contentDescription = null, tint = Color.White, modifier = Modifier.size(54.dp))
        }

        Spacer(modifier = Modifier.height(40.dp))

        if (recordedFile != null && !isRecording) {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Button(
                    onClick = { viewModel.analyzeRecordedCry() },
                    modifier = Modifier.weight(1.3f).height(50.dp),
                    shape = RoundedCornerShape(16.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = MeshkatPinkPrimary)
                ) {
                    Text("تحلیل با هوش مصنوعی", fontWeight = FontWeight.Bold)
                }

                OutlinedButton(
                    onClick = { viewModel.startRecording() },
                    modifier = Modifier.weight(1f).height(50.dp),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Text("ضبط دوباره", color = MeshkatPinkPrimary)
                }
            }
        }
    }
}

// ------------------- صفحه انیمیشن تحلیل (Analyzing) -------------------
@Composable
fun AnalyzingScreen() {
    Column(
        modifier = Modifier.fillMaxSize().padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text("🧸", fontSize = 64.sp)
        Spacer(modifier = Modifier.height(20.dp))
        CircularProgressIndicator(color = MeshkatPinkPrimary)
        Spacer(modifier = Modifier.height(24.dp))
        Text("دارم به صدای مشکات گوش میدم… 🧸", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = MeshkatPinkPrimary)
        Spacer(modifier = Modifier.height(8.dp))
        Text("الگوی صدای گریه در حال بررسیه…", fontSize = 14.sp, color = TextDark)
    }
}

// ------------------- صفحه نتایج (Results) -------------------
@Composable
fun ResultScreen(viewModel: MeshkatViewModel) {
    val result = viewModel.currentAnalysisResult.collectAsState().value ?: return

    Column(
        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(result.primaryCause.iconEmoji, fontSize = 48.sp)
        Spacer(modifier = Modifier.height(8.dp))
        Text("بیشترین احتمال: ${result.primaryCause.titlePersian} (${result.primaryConfidence}٪)", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = MeshkatPinkPrimary)

        Spacer(modifier = Modifier.height(16.dp))
        DisclaimerCard()
        Spacer(modifier = Modifier.height(16.dp))

        result.probabilities.forEach { item ->
            Card(
                modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("${item.cause.iconEmoji} ${item.cause.titlePersian}", fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                    Text("${item.percentage}٪", fontWeight = FontWeight.Bold, color = Color(item.cause.colorHex))
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))
        Button(
            onClick = { viewModel.navigateTo(AppScreen.RECORD) },
            modifier = Modifier.fillMaxWidth().height(50.dp),
            shape = RoundedCornerShape(16.dp),
            colors = ButtonDefaults.buttonColors(containerColor = MeshkatPinkPrimary)
        ) {
            Text("ضبط جدید")
        }
    }
}

// ------------------- صفحه خاطرات (Memories) -------------------
@Composable
fun MemoriesScreen(viewModel: MeshkatViewModel) {
    val memories by viewModel.memories.collectAsState()

    LazyColumn(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        item {
            Text("خاطرات گریه‌های مشکات 📖", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = TextDark)
            Spacer(modifier = Modifier.height(12.dp))
        }
        if (memories.isEmpty()) {
            item {
                Box(modifier = Modifier.fillMaxWidth().padding(top = 40.dp), contentAlignment = Alignment.Center) {
                    Text("هنوز تحلیلی ثبت نشده است 🌸", color = TextMuted)
                }
            }
        } else {
            items(memories) { mem ->
                val date = SimpleDateFormat("yyyy/MM/dd HH:mm", Locale.getDefault()).format(Date(mem.timestamp))
                Card(
                    modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp),
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White)
                ) {
                    Row(modifier = Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(mem.primaryCause.iconEmoji, fontSize = 28.sp)
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text("${mem.primaryCause.titlePersian} (${mem.primaryConfidence}٪)", fontWeight = FontWeight.Bold)
                            Text(date, fontSize = 11.sp, color = TextMuted)
                        }
                    }
                }
            }
        }
    }
}

// ------------------- صفحه درباره مشکات (About) -------------------
@Composable
fun AboutScreen() {
    Column(
        modifier = Modifier.fillMaxSize().padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text("🩷", fontSize = 54.sp)
        Spacer(modifier = Modifier.height(12.dp))
        Text("درباره مشکات 🩷", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = MeshkatPinkPrimary)
        Spacer(modifier = Modifier.height(16.dp))
        Text(
            text = "«این برنامه برای کوچولوی دوست‌داشتنی ما، مشکات ساخته شده است.»",
            textAlign = TextAlign.Center,
            fontSize = 15.sp,
            fontWeight = FontWeight.Medium,
            color = TextDark,
            lineHeight = 22.sp
        )
    }
}

// ------------------- کارت سلب مسئولیت اجباری -------------------
@Composable
fun DisclaimerCard() {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        color = Color(0xFFFFF3CD),
        border = BorderStroke(1.dp, Color(0xFFFFEEBA))
    ) {
        Text(
            text = "⚠️ این نتیجه فقط یک تخمین بر اساس صدای ضبط‌شده است و نمی‌تواند نیاز واقعی یا وضعیت پزشکی نوزاد را تشخیص دهد. در صورت نگرانی حتماً با پزشک مشورت کنید.",
            modifier = Modifier.padding(12.dp),
            fontSize = 11.sp,
            color = Color(0xFF856404),
            lineHeight = 18.sp
        )
    }
}