package com.example.data

import android.content.Context
import androidx.room.*
import com.example.model.CryAnalysisResult
import com.example.model.CryCause
import com.example.model.CryProbability
import kotlinx.coroutines.flow.Flow
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json

@Entity(tableName = "cry_memories")
data class CryMemoryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val timestamp: Long,
    val durationSeconds: Int,
    val primaryCause: String,
    val primaryConfidence: Int,
    val probabilitiesJson: String,
    val audioFilePath: String?,
    val hasHighPainOrDistress: Boolean
)

@Dao
interface CryMemoryDao {
    @Query("SELECT * FROM cry_memories ORDER BY timestamp DESC")
    fun getAllMemories(): Flow<List<CryMemoryEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMemory(memory: CryMemoryEntity): Long

    @Query("DELETE FROM cry_memories WHERE id = :id")
    suspend fun deleteById(id: Long)

    @Query("DELETE FROM cry_memories")
    suspend fun clearAll()
}

@Database(entities = [CryMemoryEntity::class], version = 1, exportSchema = false)
abstract class CryAppDatabase : RoomDatabase() {
    abstract fun cryMemoryDao(): CryMemoryDao

    companion object {
        @Volatile private var INSTANCE: CryAppDatabase? = null

        fun getDatabase(context: Context): CryAppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    CryAppDatabase::class.java,
                    "meshkat_cry_db"
                ).build()
                INSTANCE = instance
                instance
            }
        }
    }
}