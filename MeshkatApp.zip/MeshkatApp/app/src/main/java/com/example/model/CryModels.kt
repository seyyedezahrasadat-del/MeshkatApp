package com.example.model

import kotlinx.serialization.Serializable

enum class CryCause(
    val titlePersian: String,
    val iconEmoji: String,
    val colorHex: Long,
    val parentingTip: String
) {
    HUNGER(
        titlePersian = "گرسنگی",
        iconEmoji = "🍼",
        colorHex = 0xFFFF708D,
        parentingTip = "نوزاد احتمالاً نیاز به شیر دارد. به دنبال نشانه‌هایی مثل مکیدن انگشتان یا چرخاندن سر به سمت سینه باشید."
    ),
    SLEEPINESS(
        titlePersian = "خواب‌آلودگی و خستگی",
        iconEmoji = "😴",
        colorHex = 0xFF9C88FF,
        parentingTip = "محیط را تاریک و آرام کنید، او را در آغوش بگیرید و با نوای آرام به خوابیدنش کمک کنید."
    ),
    COMFORT_NEED(
        titlePersian = "نیاز به آرامش و آغوش",
        iconEmoji = "🤗",
        colorHex = 0xFFFF85A1,
        parentingTip = "تماس پوستی، نوازش آرام پشت، تکان دادن ملایم یا صحبت با لحن محبت‌آمیز به آرام شدن مشکات کمک می‌کند."
    ),
    DIAPER(
        titlePersian = "تعویض پوشک",
        iconEmoji = "🧷",
        colorHex = 0xFF4CD137,
        parentingTip = "پوشک نوزاد را از نظر خیس یا کثیف بودن و همچنین دمای بدن بررسی کنید."
    ),
    GAS_DISCOMFORT(
        titlePersian = "ناراحتی گوارشی / نفخ",
        iconEmoji = "💨",
        colorHex = 0xFFFBC531,
        parentingTip = "آروغ نوزاد را بگیرید، پاهای او را مثل دوچرخه‌سواری آرام حرکت دهید یا شکمش را در جهت عقربه‌های ساعت نوازش کنید."
    ),
    PAIN_DISCOMFORT(
        titlePersian = "ناراحتی یا درد احتمالی",
        iconEmoji = "❤️",
        colorHex = 0xFFE84118,
        parentingTip = "دمای بدن را بسنجید، لباس‌هایش را از نظر تنگی بررسی کنید. در صورت تداوم، حتماً با پزشک مشورت نمایید."
    );

    companion object {
        fun fromName(name: String): CryCause = entries.find { it.name == name } ?: HUNGER
    }
}

@Serializable
data class CryProbability(
    val cause: CryCause,
    val percentage: Int
)

@Serializable
data class CryAnalysisResult(
    val id: Long = 0,
    val timestamp: Long = System.currentTimeMillis(),
    val durationSeconds: Int,
    val primaryCause: CryCause,
    val primaryConfidence: Int,
    val probabilities: List<CryProbability>,
    val audioFilePath: String? = null,
    val hasHighPainOrDistress: Boolean = false
)