name: Build Android APK

on:
  push:
    branches: [ "main", "master" ]
  workflow_dispatch:

jobs:
  build:
    runs-on: ubuntu-latest
    steps:
    - uses: actions/checkout@v4

    - name: Set up JDK 17
      uses: actions/setup-java@v4
      with:
        java-version: '17'
        distribution: 'temurin'

    - name: Setup Gradle
      uses: gradle/actions/setup-gradle@v3

    - name: Build APK
      run: gradle assembleDebug

    - name: Upload APK
      uses: actions/upload-artifact@v4
      with:
        name: Meshkat-APK
        path: app/build/outputs/apk/debug/app-debug.apk
